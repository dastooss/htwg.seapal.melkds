-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Erstellungszeit: 02. Jan 2013 um 21:49
-- Server Version: 5.5.27
-- PHP-Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `seapal`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `boatinfo2`
--

CREATE TABLE IF NOT EXISTS `boatinfo2` (
  `bootsname` varchar(200) NOT NULL DEFAULT '',
  `registernr` varchar(200) NOT NULL DEFAULT '',
  `segelzeichen` varchar(200) DEFAULT NULL,
  `heimathafen` varchar(200) DEFAULT NULL,
  `yachtclub` varchar(200) DEFAULT NULL,
  `eigner` varchar(200) DEFAULT NULL,
  `versicherung` varchar(200) DEFAULT NULL,
  `rufzeichen` varchar(200) DEFAULT NULL,
  `typ` varchar(200) DEFAULT NULL,
  `konstrukteur` varchar(200) DEFAULT NULL,
  `laenge` double DEFAULT NULL,
  `breite` double DEFAULT NULL,
  `tiefgang` double DEFAULT NULL,
  `masthoehe` double DEFAULT NULL,
  `verdraengung` double DEFAULT NULL,
  `rigart` varchar(200) DEFAULT NULL,
  `baujahr` int(11) DEFAULT NULL,
  `motor` varchar(200) DEFAULT NULL,
  `tankgroesse` double DEFAULT NULL,
  `wassertankgroesse` double DEFAULT NULL,
  `abwassertankgroesse` double DEFAULT NULL,
  `grosssegelgroesse` double DEFAULT NULL,
  `genuagroesse` double DEFAULT NULL,
  `spigroesse` double DEFAULT NULL,
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`registernr`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Daten für Tabelle `boatinfo2`
--

INSERT INTO `boatinfo2` (`bootsname`, `registernr`, `segelzeichen`, `heimathafen`, `yachtclub`, `eigner`, `versicherung`, `rufzeichen`, `typ`, `konstrukteur`, `laenge`, `breite`, `tiefgang`, `masthoehe`, `verdraengung`, `rigart`, `baujahr`, `motor`, `tankgroesse`, `wassertankgroesse`, `abwassertankgroesse`, `grosssegelgroesse`, `genuagroesse`, `spigroesse`, `ID`) VALUES
('Neuste Teil', '1', '1', '1', '1', '1', '1', '1', '1', '1', 1, 1, 1, 1, 1, '1', 1990, '1', 1, 1, 1, 1, 1, 1, 12),
('Marcis Boot2', '123456', 'ME', 'Krauchenwies', '1.YC ME', 'auch', 'jop', 'ME', '1A', 'Marci', 10, 4, 1, 7, 2, 'halt auch', 2012, '5', 5, 4, 3, 15, 10, 6, 5),
('DanielsBoot', '1234567890', 'Geil', 'Konstanz', 'Geil', 'Daniel', 'Geil', 'Geil', 'Geil', 'Daniel', 100, 30, 10, 100, 150, 'Geil', 1990, 'Geil 8.0', 100, 100, 12, 300, 31, 141, 9),
('Noch Ein Boot', '12455189', 'asd123', '12', '12', '12', '12', '12', 'ganz gut', 'jemand', 12, 12, 12, 12, 12, '12', 1912, 'i-einer', 12, 12, 12, 12, 12, 12, 11),
('Marcis Boot2', '2', 'ME', 'Krauchenwies', '1.YC ME', 'auch', 'jop', 'ME', '1A', 'Marci', 10, 4, 1, 7, 2, 'halt auch', 2012, '5', 5, 4, 3, 15, 10, 6, 13),
('DanielsBoot', '3', 'Geil', 'Konstanz', 'Geil', 'Daniel', 'Geil', 'Geil', 'Geil', 'Daniel', 100, 30, 10, 100, 150, 'Geil', 1990, 'Geil 8.0', 100, 100, 12, 300, 31, 141, 18);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `entryinfo`
--

CREATE TABLE IF NOT EXISTS `entryinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `gradn` double DEFAULT NULL,
  `minn` double DEFAULT NULL,
  `sekn` double DEFAULT NULL,
  `grade` double DEFAULT NULL,
  `mine` double DEFAULT NULL,
  `seke` double DEFAULT NULL,
  `cog` varchar(200) DEFAULT NULL,
  `sog` varchar(200) DEFAULT NULL,
  `btm` varchar(200) DEFAULT NULL,
  `dtm` varchar(200) DEFAULT NULL,
  `fahr` varchar(50) DEFAULT NULL,
  `manoever` varchar(200) DEFAULT NULL,
  `vorsegel` varchar(200) DEFAULT NULL,
  `grosssegel` varchar(200) DEFAULT NULL,
  `zeitpunkt` char(8) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Daten für Tabelle `entryinfo`
--

INSERT INTO `entryinfo` (`id`, `name`, `gradn`, `minn`, `sekn`, `grade`, `mine`, `seke`, `cog`, `sog`, `btm`, `dtm`, `fahr`, `manoever`, `vorsegel`, `grosssegel`, `zeitpunkt`) VALUES
(1, 'Test', 132, 5, 3, 15, 2, 66, 'cog', 'sog', 'btm', 'dtm', 'Mark 1', 'Jibe', 'Fock', 'reef 2', '0:20');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tripinfo`
--

CREATE TABLE IF NOT EXISTS `tripinfo` (
  `triptitle` varchar(200) NOT NULL DEFAULT '',
  `von` varchar(200) DEFAULT NULL,
  `nach` varchar(200) DEFAULT NULL,
  `skipper` varchar(200) DEFAULT NULL,
  `crew` varchar(200) DEFAULT NULL,
  `start` date DEFAULT NULL,
  `ende` date DEFAULT NULL,
  `dauer` varchar(20) DEFAULT NULL,
  `motor` int(11) DEFAULT NULL,
  `tank` tinyint(1) DEFAULT NULL,
  `registernr` int(11) DEFAULT NULL,
  `tripid` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`tripid`),
  KEY `tripid` (`tripid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Daten für Tabelle `tripinfo`
--

INSERT INTO `tripinfo` (`triptitle`, `von`, `nach`, `skipper`, `crew`, `start`, `ende`, `dauer`, `motor`, `tank`, `registernr`, `tripid`) VALUES
('Fettes Ding', 'Hier', 'Da', 'Marci', 'asdf Daniel Marci Kolb', '2012-10-25', '2012-10-25', '1 Stunde', 59, 1, 123456, 1),
('Fettes Ding2', 'Hier', 'Da', 'Marci', 'asdf', '2012-10-25', '2012-10-25', '3 Stunde', 59, 0, 123456, 2),
('Fettes Ding3', 'Hier', 'Da', 'Marci', 'asdf', '2012-10-25', '2012-10-25', '124 Stunde', 59, 1, 123456, 3),
('Geile Reise', 'Marci', 'Stooß', 'Master Marci', 'Marci und Stooß', '2025-10-20', '2025-10-20', '5 Stunden', 10, 0, 1234567890, 4);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
